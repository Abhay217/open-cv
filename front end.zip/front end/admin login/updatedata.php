<?php
$conn = mysqli_connect("localhost","root","","smart_attendance");
$stu_id =$_POST['id'];
$name = $_POST['name'];
$address  = $_POST['address'];
$branch = $_POST['branch'];
$phone = $_POST['phone'];
$gender	=$_POST['gender'];
$domain =$_POST['domain'];
$work =$_POST['work'];
$dob =$_POST['dob'];
$doj =$_POST['doj'];
$aadhaar =$_POST['aadhaar'];
$pan =$_POST['pan'];
$password =$_POST['password'];
$photo =$_POST['photo'];
$email =$_POST['email'];


$sql = "UPDATE `employee_profile` SET name = '$name',address = '$address',branch = '$branch',phone = '$phone',gender ='$gender',domain = '$domain',work = '$work',dob ='$dob',doj = '$doj', aadhaar ='$aadhaar',pan ='$pan', password = '$password', photo ='$photo', email ='$email' WHERE id = $stu_id";
if(!mysqli_query($conn,$sql))
{
  echo "not updatedate";
}else {
  sleep(1);
  echo "updatedate";

}

sleep(2);
header("Location:http://localhost/database/admin%20login/adminlogin.php");
mysqli_close($conn);


?>
