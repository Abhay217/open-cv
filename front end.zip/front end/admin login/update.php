<?php include 'header.php'; ?>


<div id="main-content">
    <h2>Edit Record</h2>
    <form class="post-form" action="<?php $_SERVER['PHP_SELF'];?>" method="post">
        <div class="form-group">
            <label>Id</label>
            <input type="text" name="id" />
        </div>
        <input class="submit" type="submit" name="showbtn" value="Show" />
    </form>
<<?php
if (isset($_POST['showbtn'])) {
  $conn = mysqli_connect("localhost","root","","smart_attendance") or die("connection failed");

  $stu_id = $_POST['id'];

  $sql = "SELECT * FROM `employee_profile` WHERE id = $stu_id";
  $result = mysqli_query($conn, $sql) or die("Query unsusuccessful");

  if(mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
 ?>
    <form class="post-form" action="updatedata.php" method="post">
      <div class="form-group">
          <label>Name</label>
          <input type="text" name="id" value="<?php echo $row['id']?>" />
          <input type="text" name="name" value="<?php echo $row['name']?>" />
      </div>
      <div class="form-group">
          <label>Gender</label>
          <input type="text" name="gender" value="<?php echo $row['gender']?>" />
          </select>
      </div>
      <div class="form-group">
          <label>Phone</label>
          <input type="text" name="phone"value="<?php echo $row['phone']?>"  />
      </div>
      <div class="form-group">
          <label>Address</label>
          <input type="text" name="address" value="<?php echo $row['address']?>" />
      </div>
      <div class="form-group">
          <label>Branch</label>
          <input type="text" name="branch"value="<?php echo $row['branch']?>"  />
      </div>
      <div class="form-group">
          <label>Domain</label>
          <input type="text" name="domain"value="<?php echo $row['domain']?>" />
      </div>
      <div class="form-group">
          <label>Work</label>
          <input type="text" name="work"value="<?php echo $row['work']?>"  />
      </div>
      <div class="form-group">
          <label>DOB</label>
          <input type="text" name="dob" value="<?php echo $row['dob']?>"  />
      </div>
      <div class="form-group">
          <label>DOJ</label>
          <input type="text" name="doj" value="<?php echo $row['doj']?>"  />
      </div>
      <div class="form-group">
          <label>Aadhaar</label>
          <input type="text" name="aadhaar" value="<?php echo $row['aadhaar']?>"  />
      </div>
      <div class="form-group">
          <label>PAN</label>
          <input type="text" name="pan" value="<?php echo $row['pan']?>" />
      </div>
      <div class="form-group">
          <label>Photo</label>
          <input type="text" name="photo"value="<?php echo $row['photo']?>"  />
      </div>
      <div class="form-group">
          <label>Password</label>
          <input type="text" name="password"value="<?php echo $row['password']?>"  />
      </div>
      <div class="form-group">
          <label>Email</label>
          <input type="text" name="email"value="<?php echo $row['email']?>"  />
      </div>

    <input class="submit" type="submit" value="Update"  />
    </form>
    <?php
  }
}
} ?>
</div>
</div>
</body>
</html>
