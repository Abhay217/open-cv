<?php
session_start();
$conn = mysqli_connect("localhost","root","","smart_attendance") or die("connection failed");

$email = $_SESSION['email'];
// print_r($email);
if (isset($_POST['password']))
{
$password =$_POST['password'];
  $sql = "UPDATE `admin_login` SET `password`= '$password' WHERE `email` = '$email'";
//   UPDATE `admin_login` SET `password`='001' WHERE `email`='Shukla.abhay580@gmail.com'
  print_r($sql);
  echo "<pre>";
  print_r($email);


  if(!mysqli_query($conn,$sql)>1)
{
echo "not updatedate";
}else {
sleep(1);
echo "updatedate";
header("location: http://localhost/database/admin%20login/done.php");



}

}

?>
<h2>Reset Your Account Password</h2>
<?php echo !empty($statusMsg)?'<p class="'.$statusMsgType.'">'.$statusMsg.'</p>':''; ?>
<div class="container">
    <div class="regisFrm">
        <form action="" method="post">
            <input type="password" name="password" placeholder="PASSWORD" required="">
            <input type="password" name="confirm_password" placeholder="CONFIRM PASSWORD" required="">
            <div class="send-button">

                <input type="submit" name="resetSubmit" value="RESET PASSWORD">
            </div>
        </form>
    </div>
</div>
