<?php
session_start();
  $conn = mysqli_connect("localhost","root","","smart_attendance") or die("connection failed");
  $sessData = !empty($_SESSION['sessData'])?$_SESSION['sessData']:'';
  if(!empty($sessData['status']['msg'])){
    $statusMsg = $sessData['status']['msg'];
    $statusMsgType = $sessData['status']['type'];
    unset($_SESSION['sessData']['status']);
}
?>
<h2>Enter the Email of Your Account to Reset New Password</h2>
<?php echo !empty($statusMsg)?'<p class="'.$statusMsgType.'">'.$statusMsg.'</p>':''; ?>
<div class="container">
    <div class="regisFrm">
        <form action="reset-pass.php" method="post">
            <input type="email" name="email" placeholder="EMAIL" required="">
            <div class="send-button">
                <input type="submit" name="forgotSubmit" value="CONTINUE">
            </div>
        </form>
    </div>
</div>
<?php
// if (isset($_POST['email'])) {
//   $conn = mysqli_connect("localhost","root","","par_login") or die("connection failed");
//   $email = $_POST['email'];
//   $_SESSION['email'] =$email;
//   $sql = "SELECT * FROM `par` WHERE email = $email";
//   print_r($sql);
//   echo "<pre>";
//   echo "$email";
//     echo "</pre>";
// }
if(isset($_POST['forgotSubmit']))
{
   $email = $_POST['email'];
   $_SESSION['email'] =$email;
   print_r($_SESSION['email']);
}
?>
