<?php include 'header.php'; ?>
<div id="main-content">
    <h2>Add New Record</h2>
    <form class="post-form" action="savedata.php" method="post">
        <div class="form-group">
            <label>Name</label>
            <input type="text" name="name" />
        </div>
        <div class="form-group">
            <label>Gender</label>
            <input type="text" name="gender" />
            </select>
        </div>
        <div class="form-group">
            <label>Phone</label>
            <input type="text" name="phone" />
        </div>
        <div class="form-group">
            <label>Address</label>
            <input type="text" name="address" />
        </div>
        <div class="form-group">
            <label>Branch</label>
            <input type="text" name="branch" />
        </div>
        <div class="form-group">
            <label>Domain</label>
            <input type="text" name="domain" />
        </div>
        <div class="form-group">
            <label>Work</label>
            <input type="text" name="work" />
        </div>
        <div class="form-group">
            <label>DOB</label>
            <input type="text" name="dob" />
        </div>
        <div class="form-group">
            <label>DOJ</label>
            <input type="text" name="doj" />
        </div>
        <div class="form-group">
            <label>Aadhaar</label>
            <input type="text" name="aadhaar" />
        </div>
        <div class="form-group">
            <label>PAN</label>
            <input type="text" name="pan" />
        </div>
        <div class="form-group">
            <label>PHOTO</label>
            <input type="text" name="photo" />

        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="text" name="password" />
        </div>
        <div class="form-group">
            <label>Email</label>
            <input type="text" name="email" />
        </div>

        <input class="submit" type="submit" value="Save"  />
    </form>
</div>
</div>
</body>
</html>
