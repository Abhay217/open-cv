<?php
session_start();
$output = $_SESSION['output'];
$conn = mysqli_connect("localhost","root","","smart_attendance") or die("connection failed");
$logout_date = date("F j, Y, g:i a");
date_default_timezone_set('Asia/Kolkata');
$logout_time=date('H:ia');
$login_time=$_SESSION['login_time'];

if (isset($_POST['logout'])){
$sql = "UPDATE `admin_attendance` SET `logout_date`='$logout_date',`logout_time`='$logout_time' WHERE login_time ='$login_time'";
if(!mysqli_query($conn,$sql))
{
  echo "not updatedate";
}else {
  sleep(1);
  echo "updatedate";
  header("location:http://localhost/database/admin%20login/index.php");

}
}
?>
<!doctype html>
<html>
<head>
<title> Abhay Shukla </title> </head>
<body>
<h1> Admin logout page </h1>
<form action="" method="POST">
<button type="logout" name="logout" value="logout">LOGOUT </button>
</form>
</body>
</html>