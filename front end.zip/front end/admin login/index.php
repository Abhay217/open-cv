<?php
session_start();
//login by employee
$conn = mysqli_connect("localhost","root","","smart_attendance") or die("connection failed");
if(isset($_POST['submit'])){
    $conn = mysqli_connect("localhost","root","","smart_attendance") or die("connection failed");
  $password = $_POST['password'];
  $email  = $_POST['email'];
//   $email  =  $_SESSION['email'];
  $sql ="SELECT * FROM `admin_login` WHERE email = '$email'  AND password = '$password'";
  $j="SELECT `name` FROM `admin_login` WHERE email = '$email'  AND password = '$password'";
  $result1 = mysqli_query($conn,$j);
  $row =mysqli_fetch_assoc($result1);
  $output =  $row['name'];
//   print_r($output);
  $_SESSION['output']=$output;
  date_default_timezone_set('Asia/Kolkata');
  $login_date = date("F j Y, g:i a");

  date_default_timezone_set('Asia/Kolkata');
  $login_time=date('H:ia');
  $_SESSION['login_time']=$login_time;
  $result = mysqli_query($conn,$sql);
  if(mysqli_num_rows($result) == 1)
  {

// echo "you have susuccessful login";

$sql1 ="INSERT INTO `admin_attendance`( `name`, `login_date`, `login_time`) VALUES ('$output', '$login_date','$login_time')";
if(!mysqli_query($conn,$sql1))
{
  echo "o";


}
else {
  echo "1";
  header("location: http://localhost/database/admin%20login/adminlogin.php");
  exit();}

  }
  else{
      echo "unsusuccessful login";
      exit();
      }
  }
?>
<!DOCTYPE html>
<html lang="en" class="loading">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <title>AdminLogin Page</title>

    <link rel="shortcut icon" type="image/png" href="../assets/img/ico/favicon-32.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">

    <link rel="stylesheet" type="text/css" href="../assets/vendors/css/prism.min.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/app.css">
  </head>
  <body data-col="1-column" class=" 1-column  blank-page blank-page">
  <!--Login Page Starts-->
    <div class="wrapper">
    <form action="" method="POST">
<section id="login">
    <div class="container-fluid">
        <div class="row full-height-vh">
            <div class="col-12 d-flex align-items-center justify-content-center gradient-aqua-marine">
                <div class="card px-4 py-2 box-shadow-2 width-400">
                    <div class="card-header text-center">
                        <img src="../assets/img/logos/logo-color-big.png" alt="company-logo" class="mb-3" width="80">
                        <h4 class="text-uppercase text-bold-400 grey darken-1">Admin Login Page</h4>
                    </div>
                    <div class="card-body">
                        <div class="card-block">
                            <form>
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <input type="phone" class="form-control form-control-lg" name="email" id="email" placeholder="email" required email>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-md-12">
                                        <input type="password" class="form-control form-control-lg" name="password" id="password" placeholder="password" required>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="custom-control custom-checkbox mb-2 mr-sm-2 mb-sm-0 ml-5">
                                                <input type="checkbox" class="custom-control-input" checked id="rememberme">
                                                <label class="custom-control-label float-left" for="rememberme">Remember Me</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="text-center col-md-12">
                                        <button type="submit" name="submit" class="btn btn-danger px-4 py-2 text-uppercase white font-small-4 box-shadow-2 border-0" value="submit">Submit</button>
                                        </form>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="card-footer grey darken-1">
                        <div class="text-center mb-1">
                        <form action="forgotPassword.php" method="POST">
                        <button type="forget password" class="btn btn-danger px-4 py-2 text-uppercase white font-small-4 box-shadow-2 border-0" value="forget password">FORGET PASSWORD </button>
                        </form>
                        </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--Login Page Ends-->
    </div>
  </body>

</html>
