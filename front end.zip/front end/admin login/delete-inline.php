<?php

echo $stu_id = $_GET['id'];
include 'config.php';
$sql = "DELETE FROM employee_profile where id = $stu_id";
$result = mysqli_query($conn, $sql) or die("Query unsusuccessful");



header("location: http://localhost/database/admin%20login/adminlogin.php");
mysqli_close($conn);
 ?>
