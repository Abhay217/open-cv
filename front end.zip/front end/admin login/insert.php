<?php
$Password = $_POST['password'];
$Email  = $_POST['email'];
if (!empty($Email) || (!empty($Password)))
{
$host = "localhost";
$dbUsername ="root";
$dbPassword ="";
$dbname = "smart_attendance";
} else {
echo " All field are required";
die();
}
?>
